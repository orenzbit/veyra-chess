# Windows verification checklist

Run this checklist on an actual Windows machine.

- [ ] .NET 8 Desktop Runtime is installed.
- [ ] `dotnet build -c Release` succeeds.
- [ ] `TabiaChessLauncher.exe` starts.
- [ ] The URL input accepts the real Tabia HTTPS URL.
- [ ] Save persists the URL after closing and reopening.
- [ ] Open launches the exact configured Tabia URL.
- [ ] Tabia login / private gate still works in the browser.
- [ ] Review opens and works.
- [ ] Bot Center opens.
- [ ] Adaptive page opens.
- [ ] Admin remains server-side; no secrets exist in the Windows wrapper.
- [ ] Closing the wrapper exits cleanly.
- [ ] No browser-installation requirement beyond the normal Windows default browser.
