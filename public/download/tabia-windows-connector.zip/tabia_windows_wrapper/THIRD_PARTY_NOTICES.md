# Third-Party Notices

## WPF / .NET
Repository: https://github.com/dotnet/wpf
License: MIT

The Windows wrapper uses WPF APIs. The target machine's installed .NET Desktop Runtime is an external platform prerequisite and is not bundled by this project.

## Other third-party runtime libraries
None intentionally added by this wrapper.

## WebView2 / Electron / Tauri
Not used.
