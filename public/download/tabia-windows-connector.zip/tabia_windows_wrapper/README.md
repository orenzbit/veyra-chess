# Tabia Chess Windows Connector

## What this is

A very small Windows desktop connector for the existing Tabia web application.

It does **not** reimplement the chess board, Review, Coach, bots, database, or web application.
It simply stores the Tabia URL locally and opens that exact web application using the user's default browser.

That is deliberate: there is one product and one codebase, not a second Windows implementation that can drift away from the web app.

## MIT-only design

This wrapper contains only original project code and the .NET/WPF platform APIs needed to build it. It does not add WebView2, Electron, Tauri, or another third-party runtime.

WPF itself is an MIT-licensed .NET Foundation project. See:
https://github.com/dotnet/wpf/blob/main/LICENSE.TXT

This wrapper does not redistribute a .NET runtime. The target machine must already have the matching .NET Desktop Runtime installed.

## What you need on Windows

1. Windows 10/11.
2. .NET 8 Desktop Runtime for Windows, matching the target architecture.
3. The Tabia site deployed to a real HTTPS URL.

## Build it on Windows

Install the .NET 8 SDK, open PowerShell in this folder, then run:

```powershell
dotnet restore .\TabiaChessLauncher\TabiaChessLauncher.csproj
dotnet build .\TabiaChessLauncher\TabiaChessLauncher.csproj -c Release
```

The executable will be under:

```text
TabiaChessLauncher\bin\Release\net8.0-windows\
```

## Publish a distributable folder

```powershell
dotnet publish .\TabiaChessLauncher\TabiaChessLauncher.csproj -c Release -r win-x64 --self-contained false -o .\publish\win-x64
```

This intentionally does not bundle the .NET runtime. That keeps the wrapper small and avoids silently redistributing platform runtime binaries.

For Windows ARM64, replace `win-x64` with `win-arm64`.

## Configure Tabia

On first launch, paste the HTTPS URL of the Tabia web app. For local development, HTTP is accepted only for `localhost` or `127.0.0.1`.

The connector stores only the URL under:

```text
%APPDATA%\TabiaChess\settings.json
```

No Tabia password, Admin secret, database key, or API secret is stored by this connector. The connector also rejects URLs containing embedded credentials.

## How it connects

```text
TabiaChessLauncher.exe
        |
        v
Windows default browser
        |
        v
Existing Tabia Web App
        |
        v
Your existing server / data services
```

## Why it is reliable

The connector does not depend on a web-rendering engine embedded in the desktop app. It delegates web rendering to the user's browser, so the chess application remains the same web application you already test and deploy.

I cannot run the final executable in this Linux environment, so the actual Windows build and launch must be verified on a Windows machine before calling it production-ready.
