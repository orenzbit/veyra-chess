$ErrorActionPreference = 'Stop'

$project = Join-Path $PSScriptRoot '..\TabiaChessLauncher\TabiaChessLauncher.csproj'
$output = Join-Path $PSScriptRoot '..\publish\win-x64'

Remove-Item $output -Recurse -Force -ErrorAction SilentlyContinue

dotnet restore $project
dotnet publish $project -c Release -r win-x64 --self-contained false -o $output

Write-Host ''
Write-Host "Published to: $output" -ForegroundColor Green
