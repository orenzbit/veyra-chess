$ErrorActionPreference = 'Stop'

$exe = Join-Path $PSScriptRoot '..\publish\win-x64\TabiaChessLauncher.exe'
if (-not (Test-Path $exe)) { throw "Build the app first: $exe" }

$shell = New-Object -ComObject WScript.Shell
$shortcutPath = [Environment]::GetFolderPath('Desktop') + '\Tabia Chess.lnk'
$shortcut = $shell.CreateShortcut($shortcutPath)
$shortcut.TargetPath = $exe
$shortcut.WorkingDirectory = Split-Path $exe
$shortcut.IconLocation = "$exe,0"
$shortcut.Save()

Write-Host "Created: $shortcutPath" -ForegroundColor Green
