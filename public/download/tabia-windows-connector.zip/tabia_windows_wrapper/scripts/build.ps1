$ErrorActionPreference = 'Stop'

$project = Join-Path $PSScriptRoot '..\TabiaChessLauncher\TabiaChessLauncher.csproj'

Write-Host 'Restoring...'
dotnet restore $project

Write-Host 'Building Release...'
dotnet build $project -c Release --no-restore

Write-Host ''
Write-Host 'Build complete.' -ForegroundColor Green
