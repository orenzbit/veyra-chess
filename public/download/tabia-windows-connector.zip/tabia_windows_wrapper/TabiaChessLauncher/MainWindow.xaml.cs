using System.Diagnostics;
using System.IO;
using System.Text.Json;
using System.Windows;

namespace TabiaChessLauncher;

public partial class MainWindow : Window
{
    private const string DefaultUrl = "";
    private readonly string _settingsPath;

    public MainWindow()
    {
        InitializeComponent();
        var baseDir = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "TabiaChess");
        Directory.CreateDirectory(baseDir);
        _settingsPath = Path.Combine(baseDir, "settings.json");
        UrlBox.Text = LoadUrl();
    }

    private string LoadUrl()
    {
        try
        {
            if (File.Exists(_settingsPath))
            {
                var json = File.ReadAllText(_settingsPath);
                var settings = JsonSerializer.Deserialize<Settings>(json);
                if (!string.IsNullOrWhiteSpace(settings?.Url)) return settings.Url.Trim();
            }
        }
        catch
        {
            // Corrupt local settings are ignored and replaced by the default.
        }

        return DefaultUrl;
    }

    private void SaveUrl()
    {
        var url = UrlBox.Text.Trim();
        if (!TryValidateUrl(url, out var normalized))
        {
            MessageBox.Show(
                "כתובת האתר חייבת להיות URL מסוג https:// או http://.",
                "כתובת לא תקינה",
                MessageBoxButton.OK,
                MessageBoxImage.Warning);
            return;
        }

        var json = JsonSerializer.Serialize(new Settings { Url = normalized }, new JsonSerializerOptions { WriteIndented = true });
        File.WriteAllText(_settingsPath, json);
        UrlBox.Text = normalized;
    }

    private void SaveButton_Click(object sender, RoutedEventArgs e)
    {
        try
        {
            SaveUrl();
        }
        catch (Exception ex)
        {
            MessageBox.Show($"לא הצלחתי לשמור את הכתובת.\n\n{ex.Message}", "שגיאה", MessageBoxButton.OK, MessageBoxImage.Error);
        }
    }

    private void OpenButton_Click(object sender, RoutedEventArgs e)
    {
        try
        {
            var url = UrlBox.Text.Trim();
            if (!TryValidateUrl(url, out var normalized))
            {
                MessageBox.Show(
                    "הכנס כתובת מלאה, למשל https://tabia.example.",
                    "כתובת לא תקינה",
                    MessageBoxButton.OK,
                    MessageBoxImage.Warning);
                return;
            }

            UrlBox.Text = normalized;
            File.WriteAllText(_settingsPath, JsonSerializer.Serialize(new Settings { Url = normalized }, new JsonSerializerOptions { WriteIndented = true }));

            Process.Start(new ProcessStartInfo
            {
                FileName = normalized,
                UseShellExecute = true,
            });
        }
        catch (Exception ex)
        {
            MessageBox.Show($"Windows לא הצליח לפתוח את Tabia.\n\n{ex.Message}", "שגיאה", MessageBoxButton.OK, MessageBoxImage.Error);
        }
    }

    private static bool TryValidateUrl(string value, out string normalized)
    {
        normalized = value;
        if (!Uri.TryCreate(value, UriKind.Absolute, out var uri)) return false;
        if (uri.Scheme != "https" && !(uri.Scheme == "http" && (uri.Host.Equals("localhost", StringComparison.OrdinalIgnoreCase) || uri.Host == "127.0.0.1"))) return false;
        if (!string.IsNullOrEmpty(uri.UserInfo)) return false;
        normalized = uri.AbsoluteUri;
        return true;
    }

    private void ExitButton_Click(object sender, RoutedEventArgs e)
    {
        Close();
    }

    private sealed class Settings
    {
        public string Url { get; set; } = string.Empty;
    }
}
