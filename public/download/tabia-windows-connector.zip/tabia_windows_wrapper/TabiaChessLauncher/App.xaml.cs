using System.Windows;

namespace TabiaChessLauncher;

public partial class App : Application
{
}
